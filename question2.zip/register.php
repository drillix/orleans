<?php
/**
 * Created by PhpStorm.
 * User: drillix
 * Date: 9/22/2017
 * Time: 1:08 PM
 */

$connect = mysqli_connect("localhost", "root", "", "mimi");

if(!empty($_POST))
{


    $output = '';
    $message = '';
    $firstname = mysqli_real_escape_string($connect, $_POST["firstname"]);
    $lastname = mysqli_real_escape_string($connect, $_POST["lastname"]);
    $email = mysqli_real_escape_string($connect, $_POST["email"]);
    $phone = mysqli_real_escape_string($connect, $_POST["phone"]);
    $amount= mysqli_real_escape_string($connect, $_POST["amount"]);
    $currency = mysqli_real_escape_string($connect, $_POST["currency"]);
    $pin =mysqli_real_escape_string($connect, $_POST["serial"]);
    $serial = mysqli_real_escape_string($connect, $_POST["pin"]);




        $query = "  
           INSERT INTO registration(firstname,lastname, email, phone, amount,currency,pin,serial)  
           VALUES('$firstname', '$lastname', '$email', '$phone', '$amount', '$currency','$pin','$serial');  
           ";
    $result =  mysqli_query($connect, $query);
        if ($result){
            $query = "SELECT * FROM registration WHERE pin = '".$_POST["pin"]."'";
            $result = mysqli_query($connect, $query);
            $row = mysqli_fetch_array($result);
            echo json_encode($row);
        }


}