
<?php
function GeraHash($qtd){
//Under the string $Caracteres you write all the characters you want to be used to randomly generate the code.
    $Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZ0123456789';
    $QuantidadeCaracteres = strlen($Caracteres);
    $QuantidadeCaracteres--;

    $Hash=NULL;
    for($x=1;$x<=$qtd;$x++){
        $Posicao = rand(0,$QuantidadeCaracteres);
        $Hash .= substr($Caracteres,$Posicao,1);
    }

    return $Hash;
}
$unique_serial = GeraHash(10);
$unique_pin = GeraHash(5);

?>
    <!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Login</title>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <![endif]-->

    </head>

    <body>

    <div class="container">
        <br>
        <br>
        <div class="row">
            <div class="col-md-4 col-md-offset-4">

                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Registration form</h3>
                    </div>
                    <div class="panel-body">
                        <form id="registration_form" >
                            <fieldset>

                                <br>
                                <div class="form-group">
                                    <input class="form-control" placeholder="firstname" name="firstname" type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="lastname" name="lastname" type="text" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="e-mail" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder=" Phone" name="phone" type="text" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Amount to be paid" name="amount" type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <select class="form-control"  name="currency">
                                        <option value=" ">Select Currency</option>
                                        <option>GHS</option>
                                        <option>EUR</option>
                                        <option>GBP</option>
                                        <option>USD</option>
                                    </select>
                                </div>
                                        <input type="hidden" name="pin" value="<?php echo $unique_pin;?>">
                                        <input type="hidden" name="serial" value="<?php echo $unique_serial;?>">
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="button" value="Register" name="register" id="register" class="btn btn-sm btn-success btn-block process_serial">
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>




        </div>
    </div>
    <div id="serial_Modal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add Student</h4>
                </div>
                <div class="modal-body">
                    <form method="post" id="delete_form">


                        <p>Serial Number: <input type="text" value="<?php echo $unique_serial?>" id="serial" style="border: 0px; color: #0075b0;"> </input></p>

                        <br />
                        <p>Pin:<input type="text" value="<?php echo $unique_pin?>" id="pin" style="border: 0px; color: #0075b0;"> </input></p>
                        <br />
                        <br />
                        <input type="hidden" name="student_id" id="student_id" />


                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->


    <!-- Bootstrap Core JavaScript -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>

    <script src="assets/toastr/js/toastr.min.js"></script>



    <script>



        $(document).on('click', '.process_serial', function(){
            var student_id = $(this).attr("id");
            $.ajax({
                url:"register.php",
                method:"POST",
                data:$('#registration_form').serialize(),
               success:function(){

                    $('#serial_Modal').modal('show');
                }
            });
        });</script>


    </body>

    </html>
